========================================================================
    CONSOLE APPLICATION : test_lib_gpu Project Overview
========================================================================

AppWizard has created this test_lib_gpu application for you.  

This file contains a summary of what you will find in each of the files that
make up your test_lib_gpu application.


test_lib_gpu.vcproj
    This is the main project file for VC++ projects generated using an Application Wizard. 
    It contains information about the version of Visual C++ that generated the file, and 
    information about the platforms, configurations, and project features selected with the
    Application Wizard.

test_lib_gpu.cpp
    This is the main application source file.

/////////////////////////////////////////////////////////////////////////////
Other standard files:

StdAfx.h, StdAfx.cpp
    These files are used to build a precompiled header (PCH) file
    named test_lib_gpu.pch and a precompiled types file named StdAfx.obj.

/////////////////////////////////////////////////////////////////////////////
Other notes:

AppWizard uses "TODO:" comments to indicate parts of the source code you
should add to or customize.

/////////////////////////////////////////////////////////////////////////////
