from KratosMultiphysics import _ImportApplication
from KratosMeshMovingApplication import *
application = KratosMeshMovingApplication()
application_name = "KratosMeshMovingApplication"

_ImportApplication(application, application_name)
