"""
Author: Armin Geiser
"""

def read_scalar_values_from_single_result(file, key_word):

    values = {}

    with open(file, "r") as f:

        # use readline() to read the first line
        line = f.readline()

        # read until result
        _key = "Result \""+key_word+"\""
        while not _key in line:
            try:
                line = next(f)
            except:
                raise Exception("Keyword '{}' not found in file".format(_key))

        # read until Values
        _key = "Values"
        while not _key in line:
            try:
                line = next(f)
            except:
                raise Exception("Keyword '{}' not found in file".format(_key))

        line = next(f)

        # find all values
        while not "End" in line:
            line_split = line.split()

            _id = int(line_split[0])
            _value = float(line_split[1])

            values[_id] = _value

            line = next(f)

    if not values:
        raise RuntimeError("No values found!")

    return values


