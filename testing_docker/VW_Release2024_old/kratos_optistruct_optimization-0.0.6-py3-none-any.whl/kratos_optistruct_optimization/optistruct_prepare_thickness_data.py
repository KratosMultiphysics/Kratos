"""
Author: David Schmölz
Module: kratos_input_translator
"""
from .nastran_io_tools import (
    _find_include_file_paths,
    read_node_from_line,
    read_element_from_line,
    read_properties_from_line
)

import os
import shutil
from .model import Model
from .mesh_writer import MeshWriter


#####################################################################################
class OptiStructPrepareThicknessData:


    # --------------------------------------------------------------------------
    def __init__(self, original_file, new_optistruct_directory, thickness_variable_type="free_thickness"):

        self.model = Model("model")

        self.element_type_table = {
                "CTRIA3" : "ShellThinElement3D3N",
                "CQUAD4" : "ShellThickElement3D4N",
                "CTETRA" : "SmallDisplacementElement3D4N",
                "CBUSH" : "SpringDamperElement3D2N",
                "CHEXA" : "SmallDisplacementElement3D8N",
        }

        print("The following OptiStruct input files are detected:")
        original_path, original_file_name = os.path.split(original_file)
        print("OptiStruct main file:", original_file)

        if os.path.isdir(new_optistruct_directory):
            shutil.rmtree(new_optistruct_directory)
        shutil.copytree(original_path, new_optistruct_directory)

        print("Creating new OptiStruct input directory:", new_optistruct_directory)
        new_file = f"{new_optistruct_directory}/{original_file_name}"
        self.new_input_file_paths = [new_file]
        self.new_input_file_paths.extend(_find_include_file_paths(new_file))

        self.thickness_file_path = f"{new_optistruct_directory}/{original_file_name.split('.')[0]}_thick.nas"

        self.variable_type = thickness_variable_type

    # --------------------------------------------------------------------------
    def PrepareOptistructFiles(self):
        '''Writes a thickness input files from OptiStruct and creates new optistruct input files'''
        self._read_optistruct_input()
        self._prepare_model()

        print("Creating OptiStruct thickness file:", self.thickness_file_path)
        self._write_thickness_file(self.thickness_file_path)

        print("Creating new OptiStruct input files:", self.new_input_file_paths)
        for file_path in self.new_input_file_paths:
            self._create_new_optistruct_file(file_path)


    # --------------------------------------------------------------------------
    def _read_optistruct_input(self):

        for file_path in self.new_input_file_paths:
            self._read_nodes(file_path)

        for file_path in self.new_input_file_paths:
            self._read_elements(file_path)

        for file_path in self.new_input_file_paths:
            self._read_properties(file_path)


    # --------------------------------------------------------------------------
    def _read_nodes(self, file_path):

        with open(file_path, 'r') as file:
            # loop through lines in input file
            for line in file:
                result = read_node_from_line(line, file)
                if not result:
                    continue
                node_id, x_coord, y_coord, z_coord = result
                self.model.create_node(node_id, x_coord, y_coord, z_coord)


    # --------------------------------------------------------------------------
    def _read_elements(self, file_path):

        with open(file_path, 'r') as file:
            # loop through lines in input file
            for line in file:
                result = read_element_from_line(line, file, self.element_type_table)
                if not result:
                    continue
                else:
                    element_name, element_id, property_id, nodes = result
                    if "Element" in element_name:
                        self.model.create_element(element_id, property_id, nodes, element_name)
                    elif "Condition" in element_name:
                        self.model.create_condition(element_id, property_id, nodes, element_name)


    # --------------------------------------------------------------------------
    def _read_properties(self, file_path):

        with open(file_path, 'r') as file:
            # loop through lines in input file
            for line in file:
                result = read_properties_from_line(line)
                if not result:
                    continue
                else:
                    id, material_id, name, data = result
                    self.model.create_properties(id, material_id, name, data)


    # --------------------------------------------------------------------------
    def _prepare_model(self):

        if self.variable_type == "thickness":
            # no extra property ids necessary
            return

        all_property_ids = [int(id) for id in self.model.properties.keys()]

        start_id = max(all_property_ids) + 1

        # overwrite property ids of elements
        new_pid = start_id
        self.replaced_pid = dict()
        self.replaced_element_properties = dict()
        for element in self.model.elements.values():
            self.replaced_pid[new_pid] = str(element.property_id)
            element.property_id = new_pid
            self.replaced_element_properties[element.id] = new_pid
            new_pid += 1

        # create new properties
        for new_pid in self.replaced_pid:
            original_pid = self.replaced_pid[new_pid]
            original_property = self.model.properties[original_pid]
            self.model.create_properties(str(new_pid), original_property.material_id, original_property.name, original_property.data)


    # --------------------------------------------------------------------------
    def _write_thickness_file(self, file_path):

        if self.variable_type == "thickness":
            with open(file_path, 'w') as out_file:
                for property in self.model.properties.values():
                    # dsize line to activate thickness as design variable
                    dsize_line_1 = "DSIZE".ljust(8) + property.id.rjust(8) + "PSHELL".rjust(8) + property.id.rjust(8)
                    dsize_line_2 = "".ljust(8)
                    dsize_line_3 = "".ljust(8) + "THICK".rjust(8) + str(property.data).rjust(8) + str(float(property.data)+0.001).rjust(8)
                    out_file.write(dsize_line_1 + "\n")
                    out_file.write(dsize_line_2 + "\n")
                    out_file.write(dsize_line_3 + "\n")
        elif self.variable_type == "free_thickness":
            with open(file_path, 'w') as out_file:
                for property in self.model.properties.values():
                    if property.id not in self.replaced_pid.values():
                        # pshell line to define a unique thickness for each element
                        pshell_line = "PSHELL".ljust(8) + property.id.rjust(8) + property.material_id.rjust(8) + \
                            str(property.data).rjust(8) + property.material_id.rjust(8) + "".rjust(8) + property.material_id.rjust(8)
                        out_file.write(pshell_line + "\n")

                        # dsize line to activate thickness as design variable
                        dsize_line_1 = "DSIZE".ljust(8) + property.id.rjust(8) + "PSHELL".rjust(8) + property.id.rjust(8)
                        dsize_line_2 = "".ljust(8)
                        dsize_line_3 = "".ljust(8) + "THICK".rjust(8) + str(property.data).rjust(8) + str(float(property.data)+0.001).rjust(8)
                        out_file.write(dsize_line_1 + "\n")
                        out_file.write(dsize_line_2 + "\n")
                        out_file.write(dsize_line_3 + "\n")

        else:
            raise RuntimeError(f"variable_type {self.variable_type} is invalid.")


    # --------------------------------------------------------------------------
    def _create_new_optistruct_file(self, file_path):

        _, thickness_file_name = os.path.split(self.thickness_file_path)

        temp_output = f"{file_path}_temp"

        with open(file_path, 'r') as input_file, open(temp_output, 'a') as output_file:
            # loop through lines in input file
            for line in input_file:
                line_start = line[0:11].strip()
                if line_start == "BEGIN BULK":
                    thick_include = (
                            "$$\n$$ Thickness Include\n$$\nINCLUDE "
                            f"'{thickness_file_name}'\n$$\n"
                    )
                    output_file.write(line)
                    output_file.write(thick_include)
                else:
                    if self.variable_type == "free_thickness":
                        # change element pid if element information in current line
                        element_result = read_element_from_line(line, input_file, self.element_type_table)
                        if element_result:
                            element_id = element_result[1]
                            line = line[:16] + str(self.replaced_element_properties[element_id]).rjust(8) + line[24:]
                    output_file.write(line)

        os.rename(temp_output, file_path)
