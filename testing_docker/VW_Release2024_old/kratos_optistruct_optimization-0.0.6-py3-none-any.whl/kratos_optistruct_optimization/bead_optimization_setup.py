"""
Author: Armin Geiser
"""

import os
import KratosMultiphysics

def AssignMissingDefaultsOptimizationSettings(minimal_parameters):

    this_dir = os.path.dirname(os.path.realpath(__file__))

    with open(os.path.join(this_dir, "bead_opt_default_parameters.json"),'r') as parameter_file:
        bead_opt_default_parameters = KratosMultiphysics.Parameters(parameter_file.read())

    minimal_parameters.RecursivelyAddMissingParameters(bead_opt_default_parameters)

    print("="*80)
    print("> Complete settings for bead optimization after assigning default values:")
    print(minimal_parameters)
    print("="*80)

    return minimal_parameters