
"""
Author: Armin Geiser
"""

from KratosMultiphysics.ShapeOptimizationApplication.analyzers.analyzer_base import AnalyzerBaseClass
from . import optistruct_interface
from collections import OrderedDict


class OptiStructAnalyzer(AnalyzerBaseClass):


    def __init__(self, settings):

        self.design_variables = {"shape": False, "thickness": False}
        self._AddDesignVariables(settings["optimization_settings"]["design_variables"])

        self.list_of_responses = []
        self._AddResponses(settings["optimization_settings"]["objectives"])
        self._AddResponses(settings["optimization_settings"]["constraints"])

        optistruct_command_args_parameter = settings["optistruct_settings"]["optistruct_command_args"]
        optistruct_command_args = []
        for i in range(optistruct_command_args_parameter.size()):
            optistruct_command_args.append(optistruct_command_args_parameter[i].GetString())
        self.optistruct_interfaces = []

        solver_decks = [x["solver_deck"] for x in self.list_of_responses]
        solver_decks.extend(self.GetCustomSolverDecks())
        solver_decks = list(OrderedDict.fromkeys(solver_decks))

        if not solver_decks:
            raise RuntimeError("No solver_decks have been specified!")

        fem_file = settings["optistruct_settings"]["fem_file"].GetString()
        if all(v is None for v in solver_decks):
            print("No 'solver_deck' specified in responses, using 'fem_file' for all responses.")
            solver_decks = [fem_file]
            for response in self.list_of_responses:
                response["solver_deck"] = fem_file
        elif any(v is None for v in solver_decks):
            raise RuntimeError("If 'solver_deck' is specified for any response, it needs to be specified for all!")

        if fem_file not in solver_decks:
            raise RuntimeError("'fem_file' does not match any of the used solver decks from the responses.")

        for solver_deck in solver_decks:
            self.optistruct_interfaces.append(
                optistruct_interface.OptiStructInterface(solver_deck, optistruct_command_args)
            )

    def InitializeBeforeOptimizationLoop(self):
        for optistruct_interface in self.optistruct_interfaces:
            optistruct_interface.Initialize()

    def AnalyzeDesignAndReportToCommunicator(self, current_design, optimization_iteration, communicator):
        for optistruct_interface in self.optistruct_interfaces:
            optistruct_interface.InitializeSolutionStep(current_design, optimization_iteration)

            optistruct_interface.SolveSolutionStep(current_design, optimization_iteration)

            _optistruct_values = optistruct_interface.GetValues()

            _optistruct_gradients = None
            if self.design_variables["shape"]:
                _optistruct_gradients = optistruct_interface.GetGradients()

            _optistruct_thickness_gradients = None
            if self.design_variables["thickness"]:
                _optistruct_thickness_gradients = optistruct_interface.GetThicknessGradients()

            solver_deck = optistruct_interface.original_main_file_path

            self.ReportResponseData(current_design, optimization_iteration, communicator, solver_deck, _optistruct_values, _optistruct_gradients, _optistruct_thickness_gradients)

            self.CustomReportResponseData(current_design, optimization_iteration, communicator, solver_deck, _optistruct_values, _optistruct_gradients, _optistruct_thickness_gradients)

            optistruct_interface.FinalizeSolutionStep(current_design, optimization_iteration)

    def CustomReportResponseData(self, current_design, optimization_iteration, communicator, solver_deck, _optistruct_values, _optistruct_gradients, _optistruct_thickness_gradients):
        """Report response value and gradient for custom responses ev. using the provided data from the solver_deck"""
        print(f"No custom responses reported for solver deck '{solver_deck}'")
        pass

    def GetCustomSolverDecks(self):
        """Return a list of strings, containing the paths to solver decks used in custom responses."""
        return []

    def FinalizeAfterOptimizationLoop(self):
        for optistruct_interface in self.optistruct_interfaces:
            optistruct_interface.Finalize()

    def ReportResponseData(self, current_design, optimization_iteration, communicator, solver_deck, _optistruct_values, _optistruct_gradients, _optistruct_thickness_gradients):
        for response in self.list_of_responses:

            if response["solver_deck"] != solver_deck:
                continue

            identifier = response["identifier"]
            weighting_mode = response["optistruct_weighting_mode"]

            value, gradient, thickness_gradient = self.ReadOptiStructResponseData(identifier, weighting_mode, _optistruct_values, _optistruct_gradients, _optistruct_thickness_gradients)

            # response _optistruct_values
            if communicator.isRequestingValueOf(identifier):
                communicator.reportValue(identifier, value)

            # response _optistruct_gradients
            if communicator.isRequestingGradientOf(identifier):
                communicator.reportGradient(identifier, gradient)

            # response _optistruct_thickness_gradients
            if communicator.isRequestingThicknessGradientOf(identifier):
                communicator.reportThicknessGradient(identifier, thickness_gradient)


    def ReadOptiStructResponseData(self, identifier, weighting_mode, _optistruct_values, _optistruct_gradients, _optistruct_thickness_gradients):
            value = None
            gradient = {}
            thickness_gradient = {}

            if weighting_mode == "single":
                value, gradient, thickness_gradient = _GetSingleValueAndGradient(identifier, _optistruct_values, _optistruct_gradients, _optistruct_thickness_gradients)
            elif weighting_mode == "minmax":
                value, gradient, thickness_gradient = _GetMinMaxValueAndGradient(identifier, _optistruct_values, _optistruct_gradients, _optistruct_thickness_gradients)
            elif weighting_mode == "sum":
                value, gradient, thickness_gradient = _CombineValuesAndGradientsSum(identifier, _optistruct_values, _optistruct_gradients, _optistruct_thickness_gradients)
            elif weighting_mode == "square_sum":
                value, gradient, thickness_gradient = _CombineValuesAndGradientsSquareSum(identifier, _optistruct_values, _optistruct_gradients, _optistruct_thickness_gradients)
            else:
                raise Exception("Invalid 'weighting_mode', available are 'single', 'sum', 'square_sum'!")

            if not value:
                raise Exception("OptistructAnalyzer: No response value found for '{}'".format(identifier))

            if len(gradient) == 0 and len(thickness_gradient) == 0:
                raise Exception("OptistructAnalyzer: No response gradient found for '{}'".format(identifier))

            return value, gradient, thickness_gradient

    def _AddResponses(self, list_of_response_settings):
        for i in range(list_of_response_settings.size()):
            response_i = list_of_response_settings[i]

            if response_i.Has("is_combined") and response_i["is_combined"].GetBool():
                self._AddResponses(response_i["combined_responses"])

            elif response_i["analyzer"].GetString() == "optistruct":
                identifier = response_i["identifier"].GetString()

                if len(identifier) > 8:
                    raise RuntimeError("The identifier of an OptiStruct response can be " +
                        "max. 8 characters long because OptiStruct truncates them in the " +
                        "output files. '{}' exceeds this limit!".format(identifier))

                optistruct_weighting_mode = response_i["response_settings"]["optistruct_weighting_mode"].GetString()

                if optistruct_weighting_mode == "NOT_SET_BY_USER":
                    raise RuntimeError("'optistruct_weighting_mode' setting is missing for response '{}'.".format(identifier))

                solver_deck = None
                if response_i["response_settings"].Has("solver_deck"):
                    solver_deck = response_i["response_settings"]["solver_deck"].GetString()

                self.list_of_responses.append(
                    {
                        "identifier" : identifier,
                        "optistruct_weighting_mode" : optistruct_weighting_mode,
                        "solver_deck": solver_deck
                    }
                )

    def _AddDesignVariables(self, design_variable_settings):

        # doing some tricks since the type of "design_variables" can be sub parameter or a list
        design_variable_list = []
        if design_variable_settings.IsSubParameter():
            print(f"DESIGN VARIABLE SETTINGS is SubParameter!")
            design_variable_list.append(design_variable_settings)
        else:
            print(f"DESIGN VARIABLE SETTINGS is Liste!")
            design_variable_list = design_variable_settings

        for design_variable in design_variable_list:
            if design_variable["type"].GetString() in ["thickness_parameter", "free_thickness", "free_thickness_original_vm"]:
                self.design_variables["thickness"] = True
            elif design_variable["type"].GetString() == "vertex_morphing":
                self.design_variables["shape"] = True
            else:
                raise RuntimeError(f"Design variable {design_variable['type'].GetString()} is not available!")

def _CombineValuesAndGradientsSquareSum(identifier, _optistruct_values, _optistruct_gradients, _optistruct_thickness_gradients):
    value = None
    gradient = {}
    thickness_gradient = {}

    values = []
    gradient_count = 0
    thickness_gradient_count = 0

    # square the _optistruct_values
    for _value_column in _optistruct_values:
        if _value_column["Label"] == identifier:
            _value = _value_column["Value"]
            if not value : value = 0.0
            value += _value*_value
            values.append(_value)

            #combine the gradients
            if _optistruct_gradients:
                for _gradient_column in _optistruct_gradients:
                    if _gradient_column["Label"] != _value_column["Label"]:
                        continue
                    if _value_column["Type"] not in _gradient_column["Type"]:
                        continue
                    if _gradient_column["Subcase"] != _value_column["Subcase"]:
                        continue
                    if (_gradient_column["Entity"] != _value_column["Grid/Element"]) or (_gradient_column["Entity"] == "" and _value_column["Grid/Element"] == "--"):
                        continue

                    gradient_count += 1
                    for node_id, node_gradient in _gradient_column["Gradient"].items():
                        if node_id not in gradient:
                            gradient[node_id] = [0.0, 0.0, 0.0]

                        for i in range(3):
                            gradient[node_id][i] += 2.0 * _value * node_gradient[i]

            #combine the thickness gradients
            if _optistruct_thickness_gradients:
                for _gradient_column in _optistruct_thickness_gradients:
                    if _gradient_column["Label"] != _value_column["Label"]:
                        continue
                    if _value_column["Type"] not in _gradient_column["Type"]:
                        continue
                    if _gradient_column["Subcase"] != _value_column["Subcase"]:
                        continue
                    if (_gradient_column["Entity"] != _value_column["Grid/Element"]) or (_gradient_column["Entity"] == "" and _value_column["Grid/Element"] == "--"):
                        continue

                    thickness_gradient_count += 1
                    for elem_id, elem_gradient in _gradient_column["ThicknessGradient"].items():
                            if elem_id not in gradient:
                                thickness_gradient[elem_id] = 0.0

                            thickness_gradient[elem_id] += 2.0 * _value * elem_gradient

    if _optistruct_gradients and gradient_count != len(values):
        raise Exception("Number of response gradients and values found for '{}' does not match!".format(identifier))
    if _optistruct_thickness_gradients and thickness_gradient_count != len(values):
        raise Exception("Number of response thickness gradients and values found for '{}' does not match!".format(identifier))
    if len(values) == 1:
        raise Exception("Number of response gradients and values found for '{}' is 1! - Use 'single' weighting mode!".format(identifier))

    print(f"Individual values for response {identifier}: min={min(values)}, max={max(values)}")

    return value, gradient, thickness_gradient


def _CombineValuesAndGradientsSum(identifier, _optistruct_values, _optistruct_gradients, _optistruct_thickness_gradients):
    value = None
    gradient = {}
    thickness_gradient = {}

    values = []
    gradient_count = 0
    thickness_gradient_count = 0

    # square the _optistruct_values
    for _value_column in _optistruct_values:
        if _value_column["Label"] == identifier:
            _value = _value_column["Value"]
            if not value : value = 0.0
            value += _value
            values.append(_value)

    #combine the gradients
    if _optistruct_gradients:
        for _gradient_column in _optistruct_gradients:
            if _gradient_column["Label"] == identifier:
                gradient_count += 1
                for node_id, node_gradient in _gradient_column["Gradient"].items():
                    if node_id not in gradient:
                        gradient[node_id] = [0.0, 0.0, 0.0]

                    for i in range(3):
                        gradient[node_id][i] += node_gradient[i]

    #combine the thickness gradients
    if _optistruct_thickness_gradients:
        for _gradient_column in _optistruct_thickness_gradients:
            if _gradient_column["Label"] == identifier:
                thickness_gradient_count += 1
                for elem_id, elem_gradient in _gradient_column["ThicknessGradient"].items():
                    if elem_id not in gradient:
                        thickness_gradient[elem_id] = 0.0

                    thickness_gradient[elem_id] += elem_gradient

    if _optistruct_gradients and gradient_count != len(values):
        raise Exception("Number of response gradients and values found for '{}' does not match!".format(identifier))
    if _optistruct_thickness_gradients and thickness_gradient_count != len(values):
        raise Exception("Number of response thickness gradients and values found for '{}' does not match!".format(identifier))

    if len(values) == 1:
        raise Exception("Number of response gradients and values found for '{}' is 1! - Use 'single' weighting mode!".format(identifier))

    print(f"Individual values for response {identifier}: min={min(values)}, max={max(values)}")

    return value, gradient, thickness_gradient


def _GetSingleValueAndGradient(identifier, _optistruct_values, _optistruct_gradients, _optistruct_thickness_gradients):
    value = None
    gradient = {}
    thickness_gradient = {}

    value_count = 0
    gradient_count = 0
    thickness_gradient_count = 0

    # square the _optistruct_values
    for _value_column in _optistruct_values:
        if _value_column["Label"] == identifier:
            value_count += 1
            value = _value_column["Value"]

    if value_count > 1:
        raise Exception("Multiple response values found for '{}' and mode 'single' - use 'square_sum' or 'sum'!".format(identifier))

    #combine the gradients
    if _optistruct_gradients:
        for _gradient_column in _optistruct_gradients:
            if _gradient_column["Label"] == identifier:
                gradient_count += 1
                for node_id, node_gradient in _gradient_column["Gradient"].items():
                    gradient[node_id] = node_gradient

    #combine the thickness gradients
    if _optistruct_thickness_gradients:
        for _gradient_column in _optistruct_thickness_gradients:
            if _gradient_column["Label"] == identifier:
                thickness_gradient_count += 1
                for elem_id, elem_gradient in _gradient_column["ThicknessGradient"].items():
                    thickness_gradient[elem_id] = elem_gradient

    if gradient_count > 1:
        raise Exception("Multiple response gradients found for '{}' and mode 'single' - use 'square_sum' or 'sum'!".format(identifier))

    if thickness_gradient_count > 1:
        raise Exception("Multiple response thickness gradients found for '{}' and mode 'single' - use 'square_sum' or 'sum'!".format(identifier))

    return value, gradient, thickness_gradient


def _GetMinMaxValueAndGradient(identifier, _optistruct_values, _optistruct_gradients, _optistruct_thickness_gradients):
    value = None
    gradient = {}
    thickness_gradient = {}

    index_of_max_value = 0
    values = []
    gradient_count = 0
    thickness_gradient_count = 0

    # square the _optistruct_values
    for _value_column in _optistruct_values:
        if _value_column["Label"] == identifier:
            tmp_value = _value_column["Value"]
            values.append(tmp_value)
            if not value:
                value = tmp_value
            elif tmp_value > value:
                value = tmp_value
                index_of_max_value = len(values) - 1

    if len(values) == 1:
        raise Exception("Only one response value found for '{}' and mode 'minmax' - use 'single'!".format(identifier))

    print(f"Individual values for response {identifier}: min={min(values)}, max={max(values)}")

    #combine the gradients
    if _optistruct_gradients:
        for _gradient_column in _optistruct_gradients:
            if _gradient_column["Label"] == identifier:
                if gradient_count == index_of_max_value:
                    gradient = {node_id : node_gradient for node_id, node_gradient in _gradient_column["Gradient"].items()}
                gradient_count += 1

    #combine the thickness gradients
    if _optistruct_thickness_gradients:
        for _gradient_column in _optistruct_thickness_gradients:
            if _gradient_column["Label"] == identifier:
                if thickness_gradient_count == index_of_max_value:
                    thickness_gradient = {elem_id : elem_gradient for elem_id, elem_gradient in _gradient_column["ThicknessGradient"].items()}
                thickness_gradient_count += 1

    if gradient_count == 1:
        raise Exception("Only one response gradient found for '{}' and mode 'minmax' - use 'single'!".format(identifier))

    if thickness_gradient_count == 1:
        raise Exception("Only one response thickness gradient found for '{}' and mode 'minmax' - use 'single'!".format(identifier))

    return value, gradient, thickness_gradient
