"""
Author: Armin Geiser
Module: kratos_input_translator
"""

import os
import math
import functools

def _warning_file_exists(file_path):
    if os.path.isfile(file_path):
        input("There is already a file named {} in writing destination, press enter to continue to overwrite".format(file_path.rsplit('/',1)[-1]))

def _list_digit_check(line_list, digits):
    for ii in range(0, len(line_list)):
        if len(line_list[ii]) != digits:
            a = digits-len(line_list[ii])
            if a < 0:
                line_list[ii] = line_list[ii][:a]
            elif a>0:
                line_list[ii] += a*' '
            else:
                pass
    if digits == 16:
        line_list[0] = line_list[0][0:-8]
        line_list[5] = line_list[5][0:8]
    line_string = ''.join(line_list)
    return line_string

def _find_include_file_paths(file_path):
    tmp_include_paths = []
    include_paths = []
    path, _ = os.path.split(file_path)
    with open(file_path, 'r') as file:
        for line in iter(file):
            if line[0:7] == "INCLUDE":
                include_file_path = line[7:].strip()
                tmp_path, _ = os.path.split(include_file_path)
                include_file_path = ''.join([c for c in include_file_path if c != "'"])
                if tmp_path != "":
                    raise RuntimeError("Include files in subfolders or absolute paths are not supported!")
                include_path = os.path.join(path, include_file_path)

                tmp_include_paths.append(include_path)

    for tmp_path in tmp_include_paths:
        include_paths.append(tmp_path)
        include_paths.extend(_find_include_file_paths(tmp_path))

    return include_paths

def _get_float_from_nastran_string(string):

    string = string.strip()

    positive = True
    if string[0] == '-':
        positive = False
        string = string[1:]

    string = string.replace('e', 'E')

    if '+' in string and 'E+' not in string:
        string = string.replace('+', 'E+')
    elif '-' in string and 'E-' not in string:
        string = string.replace('-', 'E-')

    val = float(string)

    if not positive:
        val *= -1.0
    return val

def _get_nastran_string_from_float(float_, digits):

    if math.isnan(float_):
        raise RuntimeError("_get_nastran_string_from_float: argument is nan!")
    try:
        #TODO find a good range where scientific notation should be used...
        if abs(float_) > 0.01 and abs(float_) < 10**(digits-3):
            string = str(float_)
            if len(string) > digits:
                return string[:digits]
            remaining_digits = digits-len(string)
            string += remaining_digits*'0'
            return string

        format_string = '{:.'+str(digits)+'E}'
        string = format_string.format(float_)

        components = string.split('E')
        base, exponent = components[0], components[1]

        exponent_int = int(exponent)
        exponent = str(int(exponent_int)) # to remove leading zeros
        if exponent_int >= 0:
            exponent = '+'+exponent

        remaining_digits = digits-len(exponent)

        string = base[:remaining_digits] + exponent
    except Exception as ex:
        print(float_, digits)
        raise ex

    return string

def _error_reading_from_line(func):
    @functools.wraps(func)
    def wrapper_for_func(line):
        try:
            return func(line)
        except ValueError as ex:
            print("An error occured reading the line:\n{}".format(line))
            raise ex
    return wrapper_for_func

def read_node_from_line(line, file):
    '''Read node information from a line and a file f, returns the read info as tuple.'''

    try:
        if line[0:5] == "GRID ":

            # Read first line
            node_id = int(line[8:24])
            x_coord = _get_float_from_nastran_string(line[24:32])
            y_coord = _get_float_from_nastran_string(line[32:40])
            z_coord = _get_float_from_nastran_string(line[40:48])


        elif line[0:5] == "GRID*":


            # Read first line
            node_id = int(line[8:24])
            x_coord = _get_float_from_nastran_string(line[40:56])
            y_coord = _get_float_from_nastran_string(line[56:72])

            # Move to next line
            line = next(file)

            # Read second line
            z_coord = _get_float_from_nastran_string(line[8:24])

        else:
            return None

        return node_id, x_coord, y_coord, z_coord

    except ValueError as ex:
        print("An error occured reading the line:\n{} from file:\n{}".format(line, file.name))
        raise ex

def read_element_from_line(line, file, element_type_table):
    '''Read element information from a line and a file f, returns the read info as tuple.'''

    # extract element type
    element_type = line[0:6].strip()

    # check if it should/can be translated, else return None
    new_element_type = element_type_table.get(element_type, None)
    if not new_element_type:
        return None

     # Triangular elements
    if element_type == "CTRIA3":

        element_id = int(line[8:16])
        property_id = int(line[16:24])
        node_1 = int(line[24:32])
        node_2 = int(line[32:40])
        node_3 = int(line[40:48])

        return  new_element_type, element_id, property_id, [node_1, node_2, node_3]

    # Quadrilateral element
    elif element_type == "CQUAD4":

        element_id = int(line[8:16])
        property_id = int(line[16:24])
        node_1 = int(line[24:32])
        node_2 = int(line[32:40])
        node_3 = int(line[40:48])
        node_4 = int(line[48:56])

        return new_element_type, element_id, property_id, [node_1, node_2, node_3, node_4]

    # Solid 4 noded element
    elif element_type == "CTETRA":

        element_id = int(line[8:16])
        property_id = int(line[16:24])
        node_1 = int(line[24:32])
        node_2 = int(line[32:40])
        node_3 = int(line[40:48])
        node_4 = int(line[48:56])

        return new_element_type, element_id, property_id,\
                                         [node_1, node_2, node_3, node_4]

     #Spring- Damper elemenet
    elif element_type == "CBUSH":

        element_id = int(line[8:16])
        property_id = int(line[16:24])
        node_1 = int(line[24:32])
        node_2 = int(line[32:40])

        return new_element_type, element_id, property_id, [node_1, node_2]

    # Solid element 8 node, only first order version is implemented with 8 nodes
    elif element_type == "CHEXA":

        element_id = int(line[8:16])
        property_id = int(line[16:24])

        node_1 = int(line[24:32])
        node_2 = int(line[32:40])
        node_3 = int(line[40:48])
        node_4 = int(line[48:56])
        node_5 = int(line[56:64])
        node_6 = int(line[64:72])

        line = next(file)

        # this elements last two nodes are written on the next line.
        # Thus here we read last two nodes from there

        if line[0:1] == '+':
            node_7 = int(line[8:16])
            node_8 = int(line[16:24])
        else:
            raise RuntimeError(" Something unexpected happened while reading CHEXA elements")


        return new_element_type, element_id, property_id, \
                             [node_1, node_2, node_3, node_4, node_5, node_6, node_7, node_8]

    else:

        return None

@_error_reading_from_line
def read_material_from_line(line):
    '''Read MAT1 of a line, returns the read info as list.'''
    if line[0:4] == "MAT1":

        material_id = line[8:16].strip()
        young_modulus = line[16:24].strip()
        poisson_ratio = line[32:40].strip()
        density = line[40:48].strip()

        return [material_id, young_modulus, poisson_ratio, density]
    else:
        return None

@_error_reading_from_line
def read_properties_from_line(line):
    '''Read properties of different elements from a line, returns the read info as list.'''

    if line[0:6] == "PSHELL":
        property_id = line[8:16].strip()
        material_id = line[16:24].strip()
        thickness = line[24:32].strip()

        return [property_id, material_id, "PSHELL", thickness]

    elif line[0:6] == "PSOLID":
        property_id = line[8:16].strip()
        material_id = line[16:24].strip()

        return [property_id, material_id, "PSOLID", None]

    elif line[0:5] == "PBUSH":
        property_id = line[8:16].strip()
        material_id = line[16:24].strip()

        return [property_id, material_id, "PBUSH", None]

    else:
        return None

@_error_reading_from_line
def read_load_condition_from_line(line):
    '''Reads point load condition of a line, returns the read info as list.'''

    if line[0:5] == "FORCE":

        bc_id = int(line[8:16].strip())
        node_id = int(line[16:24].strip())
        scale_factor = line[32:40].strip()
        x_direction = int(float(line[40:48].strip()))
        y_direction = int(float(line[48:56].strip()))
        z_direction = int(float(line[56:64].strip()))

        return ["FORCE" + str(bc_id), node_id, scale_factor, x_direction, y_direction, z_direction]
    else:
        return None

@_error_reading_from_line
def read_support_condition_from_line(line):
    '''Reads support condition of a line, returns the read info as list.'''

    if line[0:8] == "SPC     ":

        condition_set_name = "SPC" + line[8:16].strip()
        node_id = int(line[16:24].strip())
        fixed_dofs = line[24:32].strip()
        value = int(float(line[32:40].strip()))

        return [condition_set_name, node_id, fixed_dofs, value]
    else:
        return None

@_error_reading_from_line
def set_analysis_type_from_line(line):
    '''Setting the problem type, linear static or eigenfreuency '''
    if "SOL 101 " in line:
        return "linear static"
    elif "SOl 103" in line:
        return "eigenfrequency"
    else:
        return None

@_error_reading_from_line
def read_surface_load_condition_from_line(line):
    '''Reads surface load condition of a line, returns the read info as list.'''
    # Surface load conditions
    if line[0:6] == "PLOAD4":

        load_set_id = int(line[8:16].strip())
        condition_set_name = "PLOAD4_"+ str(load_set_id)
        el_id = int(line[16:24].strip())
        pressure = float((line[24:32].strip()))
        node_on_surface = int(line[56:64].strip())
        diagonal_node = int(line[64:72].strip())

        return [condition_set_name, el_id, pressure, node_on_surface, diagonal_node]
    else:
        return None

