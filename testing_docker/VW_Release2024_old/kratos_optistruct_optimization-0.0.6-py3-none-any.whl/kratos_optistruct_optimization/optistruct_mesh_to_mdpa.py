"""
Author: Armin Geiser
Module: kratos_input_translator
"""
from .nastran_io_tools import (
    _find_include_file_paths,
    read_node_from_line,
    read_element_from_line,
    read_properties_from_line
)

from .model import Model as TranslatorModel
from .model import apply_right_hand_rule_for_surface_loads
from .mesh_writer import MeshWriter


#####################################################################################
class OptiStructMeshToMdpaTranslator:


    # --------------------------------------------------------------------------
    def __init__(self, original_file, mdpa_file_to_be_created, element_type_table=None):

        self.model = TranslatorModel("structure")

        self.original_input_file_paths = [original_file]
        self.original_input_file_paths.extend(_find_include_file_paths(original_file))
        self.mdpa_file_to_be_created = mdpa_file_to_be_created

        if element_type_table:
            self.element_type_table = element_type_table
        else:
            self.element_type_table = {
                "CTRIA3" : "ShellThinElement3D3N",
                "CQUAD4" : "ShellThickElement3D4N",
                "CTETRA" : "SmallDisplacementElement3D4N",
                "CBUSH" : "SpringDamperElement3D2N",
                "CHEXA" : "SmallDisplacementElement3D8N",
            }


        print("OptiStruct main file:", original_file)
        print("The following OptiStruct input files are detected:")
        print(self.original_input_file_paths)


    # --------------------------------------------------------------------------
    def translate(self, design_node_set_name=None):
        '''Translates input files from OptiStruct format to Kratos format'''

        print("Creating mdpa file:", self.original_input_file_paths)
        self._read_optistruct_input()
        if design_node_set_name:
            self._create_surface_conditions(design_node_set_name)
        self._create_all_sub_model_part()

        writer = MeshWriter(self.mdpa_file_to_be_created, self.model)
        writer.write_mdpa()
        print("Finished translating MDPA File")


    # --------------------------------------------------------------------------
    def _read_optistruct_input(self):

        for file_path in self.original_input_file_paths:
            self._read_nodes(file_path)

        for file_path in self.original_input_file_paths:
            self._read_elements(file_path)

        for file_path in self.original_input_file_paths:
            self._read_properties(file_path)

        for file_path in self.original_input_file_paths:
            self._read_sets(file_path)


    # --------------------------------------------------------------------------
    def _create_surface_conditions(self, design_node_set_name):

        print("Generate SurfaceConditions from GRID SET '{}'."\
                                             .format(design_node_set_name))
        parent = self.model
        try:
            sub_model_part = parent.sub_model_parts[design_node_set_name]
        except KeyError:
            raise Exception("There is no GRID SET with name ’{}’ in the optistruct file!" \
                                                                .format(design_node_set_name))

        create_condition = False
        if len(parent.elements) == 0 and len(parent.conditions) != 0:
            container = parent.conditions.copy()
        else:
            container = parent.elements
            create_condition = True

        for element in container.values():
            all_nodes_found = True
            node_ids = []
            for node in element.geometry.nodes:
                if node.id not in sub_model_part.nodes:
                    all_nodes_found = False
                    break
                node_ids.append(node.id)

            if all_nodes_found:
                id = element.id
                if create_condition:
                    type_name = "SurfaceCondition3D" + str(len(node_ids)) +"N"
                    id = parent.next_free_condition_id
                    parent.create_condition(id, element.property_id, node_ids, type_name)
                sub_model_part.add_condition(id)


    # --------------------------------------------------------------------------
    def _read_sets(self, file_path):

        with open(file_path, 'r') as file:
            # loop through lines in input file
            in_set = False
            current_sub_model_part = None
            for line in file:
                if line[0:4] == "SET " and line[16:20] == "GRID":
                    in_set = True
                    set_id = line[8:16].strip()
                    self.model.add_sub_model_part(set_id)
                    current_sub_model_part = self.model.sub_model_parts[set_id]
                    continue

                if in_set:
                    if line[0] == '+':
                        start_index = 8
                        while start_index < len(line)-1:
                            node_id = line[start_index:start_index+8].strip()
                            if node_id == "": break
                            current_sub_model_part.add_node(int(node_id))
                            start_index += 8
                    else:
                        in_set = False
                        current_sub_model_part = None


    # --------------------------------------------------------------------------
    def _read_nodes(self, file_path):

        with open(file_path, 'r') as file:
            # loop through lines in input file
            for line in file:
                result = read_node_from_line(line, file)
                if not result:
                    continue
                node_id, x_coord, y_coord, z_coord = result
                self.model.create_node(node_id, x_coord, y_coord, z_coord)


    # --------------------------------------------------------------------------
    def _read_elements(self, file_path):

        with open(file_path, 'r') as file:
            # loop through lines in input file
            for line in file:
                result = read_element_from_line(line, file, self.element_type_table)
                if not result:
                    continue
                else:
                    element_name, element_id, property_id, nodes = result
                    if "Element" in element_name:
                        self.model.create_element(element_id, property_id, nodes, element_name)
                    elif "Condition" in element_name:
                        self.model.create_condition(element_id, property_id, nodes, element_name)


    # --------------------------------------------------------------------------
    def _read_properties(self, file_path):

        with open(file_path, 'r') as file:
            # loop through lines in input file
            for line in file:
                result = read_properties_from_line(line)
                if not result:
                    continue
                else:
                    id, material_id, name, data = result
                    self.model.create_properties(id, material_id, name, data)


    # --------------------------------------------------------------------------
    def _create_all_sub_model_part(self):

        self.model.add_sub_model_part("AUTO_ALL")
        sub_model_part = self.model.sub_model_parts["AUTO_ALL"]
        for id in self.model.nodes:
            sub_model_part.add_node(id)
        for id in self.model.elements:
            sub_model_part.add_element(id)
        for id in self.model.conditions:
            sub_model_part.add_condition(id)
