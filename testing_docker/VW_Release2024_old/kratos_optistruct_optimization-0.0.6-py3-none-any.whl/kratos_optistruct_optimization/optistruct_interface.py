"""
Author: Armin Geiser
"""

import os
import shutil
import subprocess
import time
import KratosMultiphysics

from .nastran_io_tools import _find_include_file_paths, _list_digit_check, _get_float_from_nastran_string, _get_nastran_string_from_float


class OptiStructInterface(object):

    _debug_skip_optistruct_run = False
    auto_restart = True
    total_waiting_time = 0
    counter = 0

    def __init__(self, file_path, optistruct_command_args):
        print("OptiStructInterface::__init__")

        self.original_main_file_path = file_path
        if not os.path.isfile(self.original_main_file_path):
            raise RuntimeError("Optistruct file does not exist: ", self.original_main_file_path)

        if optistruct_command_args == []:
            raise Exception("No OptiStruct command arguments given!")
        self.optistruct_command_args = optistruct_command_args

        self.optistruct_base_directory, self.case_name = os.path.split(self.original_main_file_path)
        self.case_name = self.case_name.replace(".fem", "")

        self.original_input_file_paths = []
        self.original_input_file_paths.append(self.original_main_file_path)

        new_paths = _find_include_file_paths(self.original_main_file_path)
        self.original_input_file_paths.extend(new_paths)

        print("The following OptiStruct input files are detected:")
        print(self.original_input_file_paths)

        OptiStructInterface.counter += 1

        self.optistruct_iterations_path = f"{OptiStructInterface.counter}_{self.case_name}_iterations"

        self.main_file_path = None
        self.gradient_file_path = None
        self.value_file_path = None
        self.thickness_file_path = None
        self.thickness_optimization = True

    def Initialize(self):
        print("OptiStructInterface::Initialize")
        if not self._debug_skip_optistruct_run:
            if os.path.isdir(self.optistruct_iterations_path):
                shutil.rmtree(self.optistruct_iterations_path)
            os.mkdir(self.optistruct_iterations_path)
        else:
            print("DEBUG:: Reusing existing optistruct results!")


    def InitializeSolutionStep(self, current_design, iteration):
        print("OptiStructInterface::InitializeSolutionStep")

        # define current paths and
        current_path = os.path.join(self.optistruct_iterations_path, str(iteration))
        self.main_file_path =  os.path.join(current_path, self.case_name + ".fem")
        self.gradient_file_path = os.path.join(current_path, self.case_name + ".0.asens")
        self.value_file_path = os.path.join(current_path, self.case_name + ".out")
        self.thickness_file_path = os.path.join(current_path, self.case_name + "_thick.nas")

        print("\t", self.main_file_path)

        if not self._debug_skip_optistruct_run:
            if os.path.isdir(current_path):
                shutil.rmtree(current_path)
            os.mkdir(current_path)
        else:
            print("DEBUG:: Reusing existing optistruct results!")

        for original_file_path in self.original_input_file_paths:
            _, file_name = os.path.split(original_file_path)
            new_file_path = os.path.join(current_path, file_name)
            self._UpdateMesh(original_file_path, new_file_path, current_design)

    def SolveSolutionStep(self, current_design, iteration):
        print("OptiStructInterface::SolveSolutionStep")
        if not self._debug_skip_optistruct_run:
            self._RunOptistruct()
        else:
            print("DEBUG:: Reusing existing optistruct results!")


    def GetValues(self):
        print("OptiStructInterface::GetValues")
        return self._ReadValues()


    def GetGradients(self):
        print("OptiStructInterface::GetGradients")
        return self._ReadGradients()

    def GetThicknessGradients(self):
        print("OptiStructInterface::GetThicknessGradients")
        return self._ReadThicknessGradients()

    def FinalizeSolutionStep(self, current_design, iteration):
        print("OptiStructInterface::FinalizeSolutionStep")
        pass


    def Finalize(self):
        print("OptiStructInterface::Finalize")
        pass


    def _RunOptistruct(self):
        print("OptiStructInterface::_RunOptistruct")
        path, file_name = os.path.split(self.main_file_path)
        command_args = self.optistruct_command_args + [file_name]
        optistruct_process = subprocess.Popen(command_args, cwd=path, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        print("> cwd         : {}".format(path))
        print("> command line: {}".format(optistruct_process.args))
        print("> process pid : {}".format(optistruct_process.pid))
        stdout, stderr = optistruct_process.communicate()
        stdout = stdout.decode()
        stderr = stderr.decode()

        # more detailed output about the optistruct process
        if "error" in stdout.lower():
            print("> process stdout:\n{}".format(stdout))
            print("> process stderr:\n{}".format(stderr))

        self._CheckOptistructRun()

    def _CheckOptistructRun(self):
        print("OptiStructInterface::_CheckOptistructRun")
        if not os.path.isfile(self.value_file_path):
            raise RuntimeError("OptiStruct output file does not exist: ", self.value_file_path)

        with open(self.value_file_path, "r") as f:
            for line in f:
                if line.startswith(" OptiStruct ERROR:"):
                    print("\n" + "#"*80)
                    print("OptiStruct run encountered an error! Please check the output file:")
                    print("'{}'".format(self.value_file_path))
                    msg = ("\nPress 'enter' to run the OptiStruct solution again!" +
                           "\nType 'stop' and press 'enter' to abort the optimization process.\n> ")
                    if self.auto_restart:
                        print(" waiting ... {}s in total".format(self.total_waiting_time))
                        time.sleep(10)
                        self.total_waiting_time += 10
                    else:
                        value = input(msg)

                        if value.lower() == "stop":
                            print("Stop Kratos optimization run after user request.")
                            print("#"*80)
                            exit(0)
                    self._RunOptistruct()

    def _UpdateMesh(self, old_file_name, new_file_name, current_design):
        print("OptiStructInterface::_UpdateMesh")
        if not os.path.isfile(old_file_name):
            raise RuntimeError("OptiStruct fem file does not exist: ", old_file_name)

        new_file = open(new_file_name,'w')
        old_file = open(old_file_name,'r')

        tmp_design_nodes = {} #loop with pybind is slow
        for node in current_design.Nodes:
            tmp_design_nodes[node.Id] = [node.X0, node.Y0, node.Z0]

        tmp_thicknesses = {}
        for property in current_design.Properties:
            tmp_thicknesses[property.Id] = property.GetValue(KratosMultiphysics.THICKNESS)

        i = 0
        for line in iter(old_file):
            i += 1
            # Two lined node input
            if line[0:5] == "GRID ":
                node_id = int(line[8:24].strip())

                coords = tmp_design_nodes.get(node_id, None)
                is_design_node = coords is not None

                if is_design_node:
                    x_n = _get_nastran_string_from_float(coords[0], 8)
                    y_n = _get_nastran_string_from_float(coords[1], 8)
                    z_n = _get_nastran_string_from_float(coords[2], 8)

                    line_ls = (["GRID",str(node_id),8*' ', str(x_n), str(y_n), str(z_n)])
                    line_to_write = _list_digit_check(line_ls, 8)
                    line_to_write = (line_to_write[0:48])
                    new_file.write(line_to_write + '\n')
                else:
                    new_file.write(line)

            elif line[0:5] == "GRID*":
                node_id = int(line[8:24].strip())

                coords = tmp_design_nodes.get(node_id, None)
                is_design_node = coords is not None

                if is_design_node:
                    x_n = _get_nastran_string_from_float(coords[0], 16)
                    y_n = _get_nastran_string_from_float(coords[1], 16)
                    z_n = _get_nastran_string_from_float(coords[2], 16)

                    line_ls = (["GRID*",str(node_id),16*' ', str(x_n), str(y_n), "*", str(z_n)])
                    line_to_write = _list_digit_check(line_ls, 16)
                    line_to_write = (line_to_write[0:72] + '\n' + line_to_write[72:96])
                    new_file.write(line_to_write + '\n')
                else:
                    new_file.write(line)
                    line = next(old_file)
                    new_file.write(line)

            elif line[0:5] == "DSIZE":
                dsize_id = int(line[8:16].strip())
                thickness = tmp_thicknesses.get(dsize_id, None)
                t = _get_nastran_string_from_float(thickness, 8)
                t_incremented = _get_nastran_string_from_float(thickness+0.001, 8)

                for _ in range(2):
                    new_file.write(line)
                    line = next(old_file)

                line_to_write = "".ljust(8) + 'THICK'.rjust(8) + t.rjust(8) + t_incremented.rjust(8)
                new_file.write(line_to_write + '\n')

            elif line[0:6] == "PSHELL":
                property_id = int(line[8:16].strip())
                material_id = int(line[16:24].strip())

                thickness = tmp_thicknesses.get(property_id, None)
                is_design_property = thickness is not None

                if is_design_property:
                    t = _get_nastran_string_from_float(thickness, 8)
                    line_to_write = "PSHELL".ljust(8) + str(property_id).rjust(8) + str(material_id).rjust(8) + \
                                    t.rjust(8) + str(material_id).rjust(8) + "".rjust(8) + str(material_id).rjust(8)
                    new_file.write(line_to_write + '\n')
                else:
                    new_file.write(line)

            else:
                new_file.write(line)

        new_file.close()
        old_file.close()


    def _ReadValues(self):
        print("OptiStructInterface::_ReadValues")
        if not os.path.isfile(self.value_file_path):
            raise RuntimeError("Objective value results file does not exist: ", self.value_file_path)

        values = []

        with open(self.value_file_path, 'r') as f:

            # use readline() to read the first line
            line = f.readline()

            # read until response table
            key = "RETAINED RESPONSES TABLE"
            while not key in line:
                try:
                    line = next(f)
                except:
                    raise Exception("Keyword '{}' not found in file".format(key))

            # skip 8 lines
            for _ in range(0,8):
                line = next(f)

            # find all response values with the identifier until separator
            separator = "-"*84
            while not separator in line:
                line_split = line.split()
                response_information = {
                    "User-ID" : line_split[0],
                    "Type" : line_split[1],
                    "Label" : line_split[2],
                    "Subcase" : line_split[3],
                    "Grid/Element" : line_split[4],
                    "DOF/Comp/Reg" : line_split[5],
                    "Value" : float(line_split[6])
                }
                values.append(response_information)

                line = next(f)

        if not values:
            raise RuntimeError("No response values found!")

        return values


    def _ReadGradients(self):
        print("OptiStructInterface::_ReadGradients")
        if not os.path.isfile(self.gradient_file_path):
            raise RuntimeError("Objective gradient results file does not exist: ", self.gradient_file_path)

        gradients = []

        with open(self.gradient_file_path, 'r') as f:

            # use readline() to read the first line
            line = f.readline()

            eof = False
            while line:
                gradients_in_block, file_ended = self._ReadGradientBlock(line, f)

                if gradients_in_block:
                    gradients.extend(gradients_in_block)

                if file_ended:
                    break

        if not gradients:
            raise RuntimeError("No response gradients found!")

        return gradients


    def _ReadGradientBlock(self, line, f):

        _gradient_columns = []

        # read until Label:
        key = "Label:"
        while not key in line:
            try:
                line = next(f)
            except:
                return None, True

        # find number of responses in this block
        n_resp = len(line.split()) - 1

        _gradient_columns = n_resp * [None]
        for i in range(n_resp):
            _gradient_columns[i] = {}

        for i, entry in enumerate(line.split()[1:]):
            _gradient_columns[i]["Label"] = entry

        line = next(f)
        for i, entry in enumerate(line.split()[1:]):
            _gradient_columns[i]["Type"] = entry

        line = next(f)
        for i, entry in enumerate(line.split()[1:]):
            _gradient_columns[i]["Component"] = entry

        line = next(f)
        entities = line.split()
        if len(entities)-1 != n_resp:
            # Entity row can be empty sometimes
            for i in range(n_resp):
                _gradient_columns[i]["Entity"] = ""
        else:
            for i, entry in enumerate(line.split()[1:]):
                _gradient_columns[i]["Entity"] = entry

        line = next(f)
        for i, entry in enumerate(line.split()[1:]):
            _gradient_columns[i]["Subcase"] = entry

        for column in _gradient_columns:
            column["Gradient"] = {}

        # .asens file stores the sensitivities first for all nodes in the x then y then z direction
        first_id = None
        dir = 0

        key = "Label:"
        while not key in line:
            try:
                line = next(f)
                if line[:4] == "GRID":
                    # for OS ver. >= 2022 where there is always space between GRID and grid_id
                    # GRID 123456789 1.23456789E-08
                    if line[4] == " ":
                        splitted_line = line.split()
                        node_id = int(splitted_line[1])
                        # read the whole line
                        all_gradient_components = splitted_line[2:]

                    # for OS ver. < 2022 where there is no space between GRID and 8 digit grid_id
                    # GRID12345678 1.23456789E-08
                    else:
                        node_id = int(line[4:14].strip())
                        # read the whole line
                        all_gradient_components = line[14:].split()

                    # read the gradient
                    if not first_id:
                        first_id = node_id
                    elif node_id == first_id:
                        dir += 1

                    #fill the values for each column
                    for i, gradient_column in enumerate(_gradient_columns):
                        gradient = gradient_column["Gradient"]

                        gradient_component = float(all_gradient_components[i])

                        if node_id not in gradient:
                            gradient[node_id] = [0.0, 0.0, 0.0]
                        gradient[node_id][dir] = gradient_component

            except StopIteration:
                if first_id:
                    return _gradient_columns, True
                else:
                    return None, True

        if first_id:
            return _gradient_columns, False
        else:
            return None, False

    def _ReadThicknessGradients(self):
        print("OptiStructInterface::_ReadThicknessGradients")
        if not os.path.isfile(self.gradient_file_path):
            raise RuntimeError("Objective gradient results file does not exist: ", self.gradient_file_path)

        thickness_gradients = []

        with open(self.gradient_file_path, 'r') as f:

            # use readline() to read the first line
            line = f.readline()

            while line:
                thickness_gradients_in_block, file_ended = self._ReadThicknessGradientBlock(line, f)
                if thickness_gradients_in_block:
                    thickness_gradients.extend(thickness_gradients_in_block)

                if file_ended:
                    break

        if not thickness_gradients:
            raise RuntimeError("No response thickness gradients found!")

        return thickness_gradients


    def _ReadThicknessGradientBlock(self, line, f):

        _gradient_columns = []

        # read until Label:
        key = "Label:"
        while not key in line:
            try:
                line = next(f)
            except:
                return None, True

        # find number of responses in this block
        n_resp = len(line.split()) - 1

        _gradient_columns = n_resp * [None]
        for i in range(n_resp):
            _gradient_columns[i] = {}

        for i, entry in enumerate(line.split()[1:]):
            _gradient_columns[i]["Label"] = entry

        line = next(f)
        for i, entry in enumerate(line.split()[1:]):
            _gradient_columns[i]["Type"] = entry

        line = next(f)
        for i, entry in enumerate(line.split()[1:]):
            _gradient_columns[i]["Component"] = entry

        line = next(f)
        entities = line.split()
        if len(entities)-1 != n_resp:
            # Entity row can be empty sometimes
            for i in range(n_resp):
                _gradient_columns[i]["Entity"] = ""
        else:
            for i, entry in enumerate(line.split()[1:]):
                _gradient_columns[i]["Entity"] = entry

        line = next(f)
        for i, entry in enumerate(line.split()[1:]):
            _gradient_columns[i]["Subcase"] = entry

        for column in _gradient_columns:
            column["ThicknessGradient"] = {}

        gradients_found = False
        key = "Label:"
        while not key in line:
            try:
                line = next(f)
                if line[:4] == "ELEM":
                    gradients_found = True
                    # for OS ver. >= 2022 where there is always space between ELEM and elem_id
                    # ELEM 123456789 1.23456789E-08
                    if line[4] == " ":
                        splitted_line = line.split()
                        elem_id = int(splitted_line[1])
                        # read the whole line
                        all_gradient_components = splitted_line[2:]

                    # for OS ver. < 2022 where there is no space between ELEM and 8 digit elem_id
                    # ELEM12345678 1.23456789E-08
                    else:
                        elem_id = int(line[4:14].strip())
                        # read the whole line
                        all_gradient_components = line[14:].split()

                    #fill the values for each column
                    for i, gradient_column in enumerate(_gradient_columns):
                        gradient = gradient_column["ThicknessGradient"]

                        gradient_component = float(all_gradient_components[i])

                        if elem_id not in gradient:
                            gradient[elem_id] = 0.0
                        gradient[elem_id] += gradient_component / 0.001

            except StopIteration:
                if gradients_found:
                    return _gradient_columns, True
                else:
                    return None, True

        if gradients_found:
            return _gradient_columns, False
        else:
            return None, False
