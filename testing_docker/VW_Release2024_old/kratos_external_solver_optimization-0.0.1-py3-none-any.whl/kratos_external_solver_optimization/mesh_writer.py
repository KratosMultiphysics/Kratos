"""
Author: Armin Geiser, Oguz Oztoprak
Module: kratos_input_translator

Writer functions to be used in each translator class, as they will all have the same interface.
"""
import os

def _warning_file_exists(file_path):
    if os.path.isfile(file_path):
        input("There is already a file named {} in writing destination, press enter to continue to overwrite".format(file_path.rsplit('/',1)[-1]))


class MeshWriter:
    ''' Writes given a model and a path, the corresponding mdpa and json files'''

    def __init__(self, mdpa_file_to_be_created, model):

        self.mdpa_file_to_be_created = mdpa_file_to_be_created
        self.path_to_write = mdpa_file_to_be_created.rsplit('/', 1)[0]
        self.model = model
        self.name_of_mdpa = self.mdpa_file_to_be_created.rsplit('/', 1)[-1].rsplit('.', 1)[0]


    # --------------------------------------------------------------------------
    def write_mdpa(self):
        ''' Writes mdpa file '''

        # Warning message
        _warning_file_exists(self.mdpa_file_to_be_created)

        with open(self.mdpa_file_to_be_created, 'w') as out_file:
            self._write_properties(out_file)
            self._write_nodes(out_file)
            self._write_elements(out_file)
            self._write_conditions(out_file)
            self._write_sub_model_parts(out_file)


    # --------------------------------------------------------------------------
    def _write_properties(self, out_file):
        #default property for shapeOptimizationCondition

        out_file.write("Begin Properties 0\n")
        out_file.write("End Properties\n\n")
        for property_id in self.model.properties:
            out_file.write("Begin Properties "+ property_id + "\n")
            # add thickness for shells
            if self.model.properties[property_id].name == "PSHELL":
                out_file.write("THICKNESS " + self.model.properties[property_id].data + "\n")
            out_file.write("End Properties\n\n")


    # --------------------------------------------------------------------------
    def _write_nodes(self, out_file):
        out_file.write("Begin Nodes\n")
        for node in sorted(self.model.nodes.values()):
            out_file.write("    ")
            out_file.write(str(node.id))
            out_file.write("    ")
            out_file.write(str(node.x))
            out_file.write("    ")
            out_file.write(str(node.y))
            out_file.write("    ")
            out_file.write(str(node.z))
            out_file.write("\n")
        out_file.write("End Nodes\n\n")


    # --------------------------------------------------------------------------
    def _write_elements(self, out_file):

        for type_name in sorted(self.model.element_types):
            out_file.write("Begin Elements "+type_name+"\n")
            for element in self.model.elements.values():
                if element.type_name != type_name:
                    continue
                out_file.write("    ")
                out_file.write(str(element.id))
                out_file.write("    ")
                out_file.write(str(element.property_id))
                for node in element.geometry.nodes:
                    out_file.write("    ")
                    out_file.write(str(node.id))
                out_file.write("\n")
            out_file.write("End Elements\n\n")


    # --------------------------------------------------------------------------
    def _write_conditions(self, out_file):

        for type_name in sorted(self.model.condition_types):
            out_file.write("Begin Conditions "+type_name+"\n")
            for condition in self.model.conditions.values():
                if condition.type_name != type_name:
                    continue
                out_file.write("    ")
                out_file.write(str(condition.id))
                out_file.write("    ")
                out_file.write(str(condition.property_id))
                for node in condition.geometry.nodes:
                    out_file.write("    ")
                    out_file.write(str(node.id))
                out_file.write("\n")
            out_file.write("End Conditions\n\n")


    # --------------------------------------------------------------------------
    def _write_sub_model_parts(self, out_file):

        for sub_model_part in self.model.sub_model_parts.values():
            out_file.write("Begin SubModelPart "+sub_model_part.name+"\n")
            out_file.write("\tBegin SubModelPartNodes\n")
            for node in sorted(sub_model_part.nodes.values()):
                out_file.write("\t\t"+str(node.id)+"\n")
            out_file.write("\tEnd SubModelPartNodes\n")
            out_file.write("\tBegin SubModelPartElements\n")
            for element in sorted(sub_model_part.elements.values()):
                out_file.write("\t\t"+str(element.id)+"\n")
            out_file.write("\tEnd SubModelPartElements\n")
            out_file.write("\tBegin SubModelPartConditions\n")
            for element in sub_model_part.conditions.values():
                out_file.write("\t\t"+str(element.id)+"\n")
            out_file.write("\tEnd SubModelPartConditions\n")
            out_file.write("End SubModelPart\n\n")
