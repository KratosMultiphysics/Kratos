"""
Author: David Schmölz
"""

import os
import shutil
import KratosMultiphysics as KM


class ExternalInterface(object):

    counter = 0

    def __init__(self, external_solver, file_path):

        self.external_solver = external_solver

        # 3 file paths available: original files, current iteration, previous iteration
        self.original_path = file_path
        if not os.path.isdir(self.original_path):
            raise RuntimeError("External directory does not exist: ", self.original_path)
        self.current_iteration_path = None
        self.previous_iteration_path = None

        ExternalInterface.counter += 1

        self.case_name = external_solver.GetCaseName()
        self.iterations_path_name = f"{ExternalInterface.counter}_{self.case_name}_iterations"

        self.previous_shape = None
        self.previous_thickness = None

    def Initialize(self):
        print("ExternalInterface::Initialize")
        if os.path.isdir(self.iterations_path_name):
            shutil.rmtree(self.iterations_path_name)
        os.mkdir(self.iterations_path_name)

    def InitializeSolutionStep(self, current_design, iteration):
        print("ExternalInterface::InitializeSolutionStep")

        # define current path and copy solver files to it
        self.current_iteration_path = os.path.join(self.iterations_path_name, str(iteration))

        # create new iteration path
        if os.path.isdir(self.current_iteration_path):
            shutil.rmtree(self.current_iteration_path)
        os.mkdir(self.current_iteration_path)

        self.external_solver.CopyInputFilesToCurrentIteration(self.current_iteration_path,
                                                              self.previous_iteration_path,
                                                              self.original_path,
                                                              iteration)

        shape, thickness = self._GetShapeAndThickness(current_design)
        shape_update, thickness_update = self._GetShapeAndThicknessUpdate(current_design)

        self.external_solver.UpdateMesh(self.current_iteration_path,
                                        self.previous_iteration_path,
                                        self.original_path,
                                        iteration,
                                        shape_update, thickness_update,
                                        shape, thickness, current_design)

        self.previous_shape = shape.copy()
        self.previous_thickness = thickness.copy()
        self.previous_iteration_path = self.current_iteration_path

    def SolveSolutionStep(self, current_design, iteration):
        print("ExternalInterface::SolveSolutionStep")
        self.external_solver.RunAnalysis(self.current_iteration_path,
                                         current_design,
                                         iteration)

    def GetResponseValue(self, identifier, current_design, iteration):
        print(f"ExternalInterface::GetResponseValue for response {identifier}")
        return self.external_solver.ReadValue(identifier,
                                              self.current_iteration_path,
                                              current_design,
                                              iteration)

    def GetResponseShapeGradient(self, identifier, current_design, iteration):
        print(f"ExternalInterface::GetResponseShapeGradient for response {identifier}")
        return self.external_solver.ReadShapeGradient(identifier,
                                                      self.current_iteration_path,
                                                      current_design,
                                                      iteration)

    def GetResponseThicknessGradient(self, identifier, current_design, iteration):
        print(f"ExternalInterface::GetResponseThicknessGradient for response {identifier}")
        return self.external_solver.ReadThicknessGradient(identifier,
                                                          self.current_iteration_path,
                                                          current_design,
                                                          iteration)

    def FinalizeSolutionStep(self, current_design, optimization_iteration):
        print("ExternalInterface::FinalizeSolutionStep")
        pass

    def _GetShapeAndThicknessUpdate(self, current_design):

        shape_update = {}
        for node in current_design.Nodes:
            if self.previous_shape:
                delta_x = node.X0 - self.previous_shape[node.Id][0]
                delta_y = node.Y0 - self.previous_shape[node.Id][1]
                delta_z = node.Z0 - self.previous_shape[node.Id][2]
                shape_update[node.Id] = [delta_x, delta_y, delta_z]
            else:
                shape_update[node.Id] = [0, 0, 0]

        thickness_update = {}
        for condition in current_design.Conditions:
            if self.previous_thickness:
                delta_t = condition.Properties.GetValue(KM.THICKNESS) - self.previous_thickness[condition.Id]
                thickness_update[condition.Id] = delta_t
            else:
                thickness_update[condition.Id] = 0

        return shape_update, thickness_update

    def _GetShapeAndThickness(self, current_design):

        shape = {}
        for node in current_design.Nodes:
            shape[node.Id] = [node.X0, node.Y0, node.Z0]

        thickness = {}
        for condition in current_design.Conditions:
            thickness[condition.Id] = condition.Properties.GetValue(KM.THICKNESS)

        return shape, thickness
