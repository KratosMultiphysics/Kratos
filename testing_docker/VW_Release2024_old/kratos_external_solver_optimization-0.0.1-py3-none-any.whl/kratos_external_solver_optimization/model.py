"""
Author: Armin Geiser
Module: kratos_input_translator
"""

from abc import abstractmethod

def apply_right_hand_rule_for_surface_loads(diagonal_node, element_under_pressure):
    ''' The order of which the nodes are written for surface load is determined here '''
    node_id_list = []
    if len(element_under_pressure.geometry.nodes) != 4:
        raise RuntimeError('surface loads only allowed for 4 noded elements for now')

    for node in element_under_pressure.geometry.nodes:
        node_id_list.append(node.id)

    nodes_of_element = element_under_pressure.geometry.nodes
    index_of_the_diag_node_in_element = 0
    for node in nodes_of_element:
        if node.id == diagonal_node:
            break
        index_of_the_diag_node_in_element += 1
    #Below is the right hand rule
    if index_of_the_diag_node_in_element == 0:
        return [node_id_list[3], node_id_list[1], node_id_list[2]]

    elif index_of_the_diag_node_in_element == 1:
        return [node_id_list[3], node_id_list[2], node_id_list[0]]

    elif index_of_the_diag_node_in_element == 2:
        return [node_id_list[3], node_id_list[0], node_id_list[1]]

    #index_of_the_diag_node_in_element == 3:
    else:
        return [node_id_list[2], node_id_list[1], node_id_list[0]]

class Node(object):
    def __init__(self, id, x, y, z):
        self.id = id
        self.x = x
        self.y = y
        self.z = z
    def __lt__(self, other):
        return self.id < other.id

class Geometry(object):
    def __init__(self, nodes):
        self.nodes = nodes

class Element(object):
    def __init__(self, id, property_id, nodes, type_name):
        self.id = id
        self.property_id = property_id
        self.geometry = Geometry(nodes)
        self.type_name = type_name
    def __lt__(self, other):
        return self.id < other.id

class Condition(Element):
    def __init__(self, id, property_id, nodes, type_name):
        super(Condition, self).__init__(id, property_id, nodes, type_name)

class Property(object):
    def __init__(self, id, material_id, name, data = None):
        self.id = id
        self.material_id = material_id
        self.name = name
        self.data = data

class AbstractCondition(object):
    @abstractmethod
    def __init__(self, condition_set_name):
        self.condition_set_name = condition_set_name

class PointLoadCondition(AbstractCondition):
    def __init__(self, condition_set_name, node_id, scale_factor, x_dir, y_dir, z_dir):
        super().__init__(condition_set_name)
        self.node_id = node_id
        self.scale_factor = scale_factor
        self.x_dir = x_dir
        self.y_dir = y_dir
        self.z_dir = z_dir
        self.condition_id = 0

class SurfaceLoadCondition(AbstractCondition):
    def __init__(self, condition_set_name, element_id, pressure, node_on_surface, diagonal_node):
        super().__init__(condition_set_name)
        self.element_id = element_id
        self.pressure = pressure
        self.node_on_surface = node_on_surface
        self.diagonal_node = diagonal_node

class SupportCondition(AbstractCondition):
    def __init__(self, condition_set_name, node_id, fixed_dofs, value):
        super().__init__(condition_set_name)
        self.node_id = node_id
        self.fixed_dofs = fixed_dofs
        self.value = value

class Material(object):
    def __init__(self, material_id, young_modulus, poisson_ratio, density):
        self.material_id = material_id
        self.young_modulus = young_modulus
        self.poisson_ratio = poisson_ratio
        self.density = density if density else "7.85-9"

class Model(object):
    def __init__(self, name, parent=None):
        self.parent = parent
        self.name = name
        self.nodes = {}
        self.elements = {}
        self.conditions = {}
        self.sub_model_parts = {}
        self.point_load_conditions = {}
        self.surface_load_conditions = {}
        self.support_conditions = {}
        self.properties = {}
        self.materials = {}
        self.analysis_type = "linear static"

        self.next_free_condition_id = 1

        self.element_types = set()
        self.condition_types = set()
        self.has_solid_elements = False

    def create_node(self, id, x, y, z):
        if id in self.nodes:
            raise RuntimeError('The model already contains a node with id {}'.format(id))
        self.nodes[id] = Node(id, x, y, z)

    def add_node(self, id):
        if id in self.nodes:
            raise RuntimeError('The model already contains a node with id {}'.format(id))

        node = self.parent.nodes.get(int(id))

        if node is None:
            raise RuntimeError('The parent model does not contain a node with id {}'.format(id))
        self.nodes[id] = node

    def create_properties(self, id, material_id, name, data):
        if id in self.properties:
            if name=="PBUSH" or name=="PBUSHT":
                print(f"Ignore duplicated property {name}.")
                return
            raise RuntimeError('The model already contains a property with name {} and id {}' \
                                                                                .format(name, id))

        self.properties[id] = Property(id,material_id, name, data)

    def create_material(self, material_id, young_modulus, poisson_ratio, density):
        if material_id in self.materials:
            raise RuntimeError('The model already contains a material with id {}' \
                                                                             .format(material_id))

        self.materials[material_id] = Material(material_id, young_modulus, poisson_ratio, density)

    def create_element(self, id, property_id, node_ids, type_name):
        if id in self.elements:
            raise RuntimeError('The model already contains an element with id {}'.format(id))

        nodes = []
        for node_id in node_ids:
            #node_id is int here
            node = self.nodes.get(node_id, None)
            if node is None:
                raise RuntimeError('The model does not contain a node with id {}'.format(id))
            nodes.append(node)
        self.elements[id] = Element(id, property_id, nodes, type_name)
        self.element_types.add(type_name)

    def add_element(self, id):
        if id in self.elements:
            raise RuntimeError('The model already contains an element with id {}'.format(id))

        element = self.parent.elements.get(int(id), None)
        if element is None:
            raise RuntimeError('The parent model does not contain an element with id {}'.format(id))

        self.elements[id] = element

    def find_element_with_id(self, id):
        if int(id) not in self.elements:
            raise RuntimeError('Could not find the element with id {}'.format(id))

        return self.elements[int(id)]

    def create_condition(self, id, property_id, node_ids, type_name):
        if id in self.conditions:
            raise RuntimeError('The model already contains an condition with id {}'.format(id))

        nodes = []
        for node_id in node_ids:
            node = self.nodes.get(int(node_id))
            if node is None:
                raise RuntimeError('The model does not contains a node with id {}'.format(id))
            nodes.append(node)

        self.conditions[id] = Condition(id, property_id, nodes, type_name)

        if id >= self.next_free_condition_id:
            self.next_free_condition_id = id + 1

        self.condition_types.add(type_name)

    def add_condition(self, id):
        if id in self.conditions:
            raise RuntimeError('The model already contains an condition with id {}'.format(id))

        condition = self.parent.conditions.get(id, None)
        if condition is None:
            raise RuntimeError('The parent model does not contain an condition with id {}' \
                                                                                .format(id))

        self.conditions[id] = condition

    def create_point_load_condition(self, condition_set_name, node_id, scale_factor, x_dir, y_dir, z_dir):

        node = self.nodes.get(int(node_id))

        if node is None:
            raise RuntimeError('Cant create point load condition, the model does not contains a node with id {}'.format(node_id))

        if condition_set_name in self.point_load_conditions:
            self.point_load_conditions[condition_set_name].append( \
                    PointLoadCondition(condition_set_name, node_id, scale_factor, x_dir, y_dir, z_dir))
        else:
            self.point_load_conditions[condition_set_name] = []
            self.point_load_conditions[condition_set_name].append( \
                    PointLoadCondition(condition_set_name, node_id, scale_factor, x_dir, y_dir, z_dir))

    def create_surface_load_condition(self, condition_set_name, el_id, pressure, node_on_surface, diagonal_node):

        if condition_set_name in self.surface_load_conditions:
            self.surface_load_conditions[condition_set_name].append( \
                    SurfaceLoadCondition(condition_set_name, el_id, pressure, node_on_surface, diagonal_node))
        else:
            self.surface_load_conditions[condition_set_name] = []
            self.surface_load_conditions[condition_set_name].append( \
                    SurfaceLoadCondition(condition_set_name, el_id, pressure, node_on_surface, diagonal_node))

    def create_support_condition(self, condition_set_name, node_id, fixed_dofs, value):

        node = self.nodes.get(int(node_id))
        if node is None:
            raise RuntimeError('Cant create support condition, the model does not contains a node with id {}'.format(node_id))

        if condition_set_name in self.support_conditions:
            self.support_conditions[condition_set_name].append( \
                    SupportCondition(condition_set_name, node_id, fixed_dofs, value))
        else:
            self.support_conditions[condition_set_name] = []
            self.support_conditions[condition_set_name].append( \
                    SupportCondition(condition_set_name, node_id, fixed_dofs, value))

    def add_sub_model_part(self, name):
        if name in self.sub_model_parts:
            raise RuntimeError('The model already contains a sub model part with id {}' \
                                                                             .format(name))

        self.sub_model_parts[name] = Model(name, self)

    def has_rotation_dofs(self):
        ''' Returns a boolean that shows whether model has rotational dofs or not '''
        has_rotation_dofs = False
        for my_property in self.properties.values():
            if my_property.name == "PSHELL":
                has_rotation_dofs = True
                break
        return has_rotation_dofs
