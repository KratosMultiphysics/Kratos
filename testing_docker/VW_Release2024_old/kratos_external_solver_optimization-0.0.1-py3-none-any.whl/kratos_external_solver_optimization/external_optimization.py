
"""
Author: David Schmölz
"""

# Import Kratos core and apps
import KratosMultiphysics
import KratosMultiphysics.ShapeOptimizationApplication
from KratosMultiphysics.ShapeOptimizationApplication import optimizer_factory

from .external_analyzer import ExternalAnalyzer
from .external_interface import ExternalInterface
from .optimization_setup import AssignMissingDefaultsOptimizationSettings


class ExternalOptimization(object):

    def __init__(self, optimization_parameter_file_name, external_solver, external_solver_parameter_file_name=None):

        with open(optimization_parameter_file_name,'r') as parameter_file:
            minimal_parameters = KratosMultiphysics.Parameters(parameter_file.read())

        self.optimization_parameters = AssignMissingDefaultsOptimizationSettings(minimal_parameters)

        self.external_solver = external_solver(external_solver_parameter_file_name)

        external_interface = ExternalInterface(self.external_solver, self.external_solver.GetOriginalFilePath())

        print(f"self.optimization_parameters: {self.optimization_parameters}")
        self.external_analyzer = ExternalAnalyzer(self.optimization_parameters, external_interface)

    def RunOptimization(self):

        self.external_solver.InitializeBeforeOptimization()

        self.external_solver.TranslateToKratosModel()

        model = KratosMultiphysics.Model()

        optimizer = optimizer_factory.CreateOptimizer(self.optimization_parameters, model, self.external_analyzer)

        optimizer.Optimize()
