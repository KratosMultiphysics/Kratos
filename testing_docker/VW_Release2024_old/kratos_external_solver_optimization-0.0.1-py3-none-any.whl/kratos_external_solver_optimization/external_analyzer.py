
"""
Author: David Schmölz
"""

from KratosMultiphysics.ShapeOptimizationApplication.analyzers.analyzer_base import AnalyzerBaseClass


class ExternalAnalyzer(AnalyzerBaseClass):

    def __init__(self, settings, external_interface):

        self.external_interface = external_interface

        self.design_variables = {"shape": False, "thickness": False}
        self._AddDesignVariables(settings["design_variables"])

        self.list_of_responses = []
        self._AddResponses(settings["objectives"])
        self._AddResponses(settings["constraints"])

    def _AddDesignVariables(self, design_variable_settings):

        for design_variable in design_variable_settings:
            if design_variable["type"].GetString() in ["thickness_parameter", "free_thickness"]:
                self.design_variables["thickness"] = True
            elif design_variable["type"].GetString() == "vertex_morphing":
                self.design_variables["shape"] = True
            else:
                raise RuntimeError(f"Design variable {design_variable['type'].GetString()} is not available!")

    def _AddResponses(self, list_of_response):
        for i in range(list_of_response.size()):
            response_i = list_of_response[i]

            if response_i["analyzer"].GetString() == self.external_interface.external_solver.solver_name:
                identifier = response_i["identifier"].GetString()

                self.list_of_responses.append(
                    {
                        "identifier" : identifier
                    }
                )

    def InitializeBeforeOptimizationLoop(self):
        self.external_interface.Initialize()

    def AnalyzeDesignAndReportToCommunicator(self, current_design, optimization_iteration, communicator):
        self.external_interface.InitializeSolutionStep(current_design, optimization_iteration)

        self.external_interface.SolveSolutionStep(current_design, optimization_iteration)

        for response in self.list_of_responses:
            identifier = response["identifier"]

            value = self.external_interface.GetResponseValue(identifier, current_design, optimization_iteration)

            if self.design_variables["shape"]:
                shape_gradient = self.external_interface.GetResponseShapeGradient(identifier, current_design, optimization_iteration)

            if self.design_variables["thickness"]:
                thickness_gradient = self.external_interface.GetResponseThicknessGradient(identifier, current_design, optimization_iteration)

            # response values
            if communicator.isRequestingValueOf(identifier):
                communicator.reportValue(identifier, value)

            # response shape gradients
            if communicator.isRequestingGradientOf(identifier):
                communicator.reportGradient(identifier, shape_gradient)

            # response thickness_gradient
            if communicator.isRequestingThicknessGradientOf(identifier):
                communicator.reportThicknessGradient(identifier, thickness_gradient)

        self.external_interface.FinalizeSolutionStep(current_design, optimization_iteration)
