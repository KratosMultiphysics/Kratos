"""
Author: David Schmoelz
"""

import os
import KratosMultiphysics as KM


def AssignMissingDefaultsOptimizationSettings(minimal_parameters):

    this_dir = os.path.dirname(os.path.realpath(__file__))

    with open(os.path.join(this_dir, "opt_default_parameters.json"),'r') as parameter_file:
        opt_default_parameters = KM.Parameters(parameter_file.read())

    minimal_parameters.RecursivelyAddMissingParameters(opt_default_parameters)

    _check_packaging(minimal_parameters)
    _check_face_angle(minimal_parameters)

    print("="*80)
    print("> Complete settings for shape optimization after assigning default values:")
    print(minimal_parameters)
    print("="*80)

    return minimal_parameters


def _check_packaging(parameters):
    for objective in parameters["objectives"]:
        _check_packaging_response(parameters, objective)

    for constraint in parameters["constraints"]:
        _check_packaging_response(parameters, constraint)


def _check_packaging_response(parameters, response):
    if response["analyzer"].GetString() != "kratos":
        return
    if response["response_settings"]["response_type"].GetString() not in ["mesh_based_packaging"]:
        return

    design_mp = _get_design_modelpart_name(parameters)

    if not response["response_settings"].Has("model_part_name"):
        response["response_settings"].AddString("model_part_name", design_mp)
        return

    mp_name = response["response_settings"]["model_part_name"].GetString()

    if mp_name == design_mp:
        return
    elif mp_name == design_mp.split(".")[0]:
        KM.Logger.PrintWarning("ShapeOpt", f"Changed model_part_name of response {response['identifier'].GetString()}.")
        response["response_settings"]["model_part_name"].SetString(design_mp)
    elif mp_name.split(".")[0] == design_mp.split(".")[0]:
        KM.Logger.PrintInfo("ShapeOpt", "Different model_part than design_surface is used!")
    else:
        raise RuntimeError(f"model_part_name of response {response['identifier'].GetString()} is invalid.")

    return


def _check_face_angle(parameters):
    pass


def _get_model_part_name(parameters):
    return parameters["model_settings"]["model_part_name"].GetString()


def _get_design_modelpart_name(parameters):
    name = parameters["model_settings"]["design_surface_sub_model_part_name"].GetString()
    if "." in name:
        raise RuntimeError("'design_surface_sub_model_part_name' can not contain '.'")
    return f"{_get_model_part_name(parameters)}.{name}"
