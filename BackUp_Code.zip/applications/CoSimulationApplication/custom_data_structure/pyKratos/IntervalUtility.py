from __future__ import print_function, absolute_import, division  # makes these scripts backward compatible with python 2.6 and 2.7

# TODO this should be implemented, see "kratos/utilities/interval_utility.h"
class IntervalUtility(object):
    def __init__(self, settings):
        pass

    def IsInInterval(self, current_time):
        return True